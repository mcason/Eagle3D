This is Eagle3D 20150122-beta

For an up to date documentation see http://www.matwei.de/doku.php?id=en:eagle3d:documentation
