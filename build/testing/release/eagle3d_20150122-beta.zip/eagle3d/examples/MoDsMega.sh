#!/bin/sh

"povray" MoDsMega.ini +W640 +H480 +A0.3 +FN +L"../povray" +O"MoDsMega.png" modsmega.pov 
